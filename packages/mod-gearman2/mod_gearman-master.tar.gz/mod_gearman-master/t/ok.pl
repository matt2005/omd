#!/usr/bin/perl

# nagios: +epn
print "test plugin OK\n";
exit 0;
