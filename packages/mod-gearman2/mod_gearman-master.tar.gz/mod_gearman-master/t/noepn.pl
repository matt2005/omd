#!/usr/bin/perl

# nagios: -epn
print "no epn should be used\n";
exit 0;
